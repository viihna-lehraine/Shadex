import * as constants from '../index/constants';

const enableAlpha: boolean = true;

export const flags: constants.Flags = {
	enableAlpha
};
